//This file deals with constants and variables
import Foundation
            /*Constant declaration*/
//use let keyword for constants
let pi = 3.14
//if we try changing the value of "pi" it will throw an error
            /*Variable declaration*/
//use var keyword for declaring variables
var length = 10
length = 20


